/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1;

/**
 *
 * @author LENOVO
 */
public class LantaiSatu extends Bangunan{
    public LantaiSatu() {
        System.out.println("Ini Daerah Tempat Tinggal");
    }
    
    @Override
    public void renovasi() {
        System.out.println("Gedung Harus Di Renovasi");
    }

    @Override
    public void didatangi() {
        System.out.println("Gedung sering didatengin orang");
    }
     
        public void penyangga(int penyangga) {
        this.penyangga = penyangga;
    }
   
    
}


