/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1;

/**
 *
 * @author LENOVO
 */
public class LantaiDua extends Bangunan{
    public LantaiDua() {
        System.out.println("Gedung temoat Ibadah (Mushalla)");
    }
    
    @Override
    public void renovasi() {
        System.out.println("Gedung Ini Biasanya Di Renovasi Satu Bulan Sekali");
    }

    @Override
    public void didatangi() {
        System.out.println("Lantai ini Sering Di Datengi orang Untuk Melakuakan Ibada sholat 5 waktu ");
        
    }
    @Override
    public void pembersihan() {
        System.out.println("biasa di bersihkan tiap hari ");
    }
    
}
    

