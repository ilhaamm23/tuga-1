/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1;

/**
 *
 * @author LENOVO
 */
public class LantaiTiga  extends Bangunan implements Gedung{
    private int Orang;

    public LantaiTiga() {
        System.out.println("Tmpat olahraga dan nongkrong");
    }
    
    private void sejuk(){
        System.out.println("gedung ini sejukk");
    }
    
    

    public int Orang() {
        return Orang;
    }
    
    public void LantaiTiga() {
        Orang();
    }

    public void Orang(int Orang) {
        this.Orang = Orang;
    }

    @Override
    public void renovasi() {
        System.out.println("lagi renovasi");
    }

    @Override
    public void didatangi() {
        System.out.println("tempat lagi ramai");
    }

    
    
    
}

