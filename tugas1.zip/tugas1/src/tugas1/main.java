/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1;

/**
 *
 * @author LENOVO
 */
public class main {

    public static void main(String[] args) {
        tugas1.LantaiSatu al = new tugas1.LantaiSatu();
        al.penyangga = 50;
        al.jenis = "Apartmen";
        System.out.println("jenis : " + al.jenis);
        al.renovasi();
        al.didatangi();
        al.penyangga(22);
        
        tugas1.LantaiDua el = new tugas1.LantaiDua();
        el.renovasi();
        al.didatangi();
        el.pembersihan();
    
        tugas1.LantaiTiga dul = new tugas1.LantaiTiga();
        
       
        dul.Orang();
        dul.Orang();
        dul.Orang(22);
        System.out.println("orang : " + dul.Orang());
        dul.renovasi();
        dul.didatangi();  
         System.out.println("");
        System.out.println("");
    }
    
}
 
    

